use utf8;
package PeaksToGenes::Schema;

# Created by DBIx::Class::Schema::Loader
# DO NOT MODIFY THE FIRST PART OF THIS FILE

use strict;
use warnings;

use base 'DBIx::Class::Schema';

__PACKAGE__->load_namespaces;


# Created by DBIx::Class::Schema::Loader v0.07025 @ 2012-06-10 02:02:34
# DO NOT MODIFY THIS OR ANYTHING ABOVE! md5sum:PX1RYvfSCURxqQIxUsI6Rw


# You can replace this text with custom code or comments, and it will be preserved on regeneration
1;
